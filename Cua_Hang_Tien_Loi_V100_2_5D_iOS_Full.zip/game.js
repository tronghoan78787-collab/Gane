(()=>{'use strict';
const VERSION='100.0';
const KEY='cuahangtienloi:v100:save1';
const imgSrc=id=>window.V100_ASSETS?.['merch/'+id]||'assets/merch/'+id+'.png';
const items=[
  {id:'drink',name:'Nước giải khát',icon:'🥤',price:18000,cost:11000,demand:20},
  {id:'snack',name:'Bánh kẹo',icon:'🍪',price:24000,cost:14000,demand:18},
  {id:'milk',name:'Sữa tươi',icon:'🥛',price:28000,cost:18000,demand:17},
  {id:'fruit',name:'Trái cây',icon:'🍎',price:26000,cost:15000,demand:14},
  {id:'noodle',name:'Mì gói',icon:'🍜',price:12000,cost:7000,demand:18},
  {id:'frozen',name:'Hàng đông lạnh',icon:'🧊',price:35000,cost:23000,demand:13}
];
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('vi-VN').format(Math.round(n||0))+'đ';
const short=n=>n>=1e6?(n/1e6).toFixed(2)+'tr':n>=1e3?Math.round(n/1000)+'k':String(Math.round(n));
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const def=()=>({version:VERSION,name:'Tiệm Chibi',cash:1254680,gems:20,energy:120,level:1,xp:0,day:1,minute:540,opened:true,sound:false,reduceMotion:false,quality:'balanced',staff:2,storeGrade:1,decor:0,rep:96,marketingEnd:0,deliveryEnd:0,deliveryItem:null,deliveryQty:0,stats:{sales:0,served:0,missed:0,orders:0,spent:0,wages:0,dayRevenue:0,dayServed:0,goodDays:0},shelves:Object.fromEntries(items.map((p,i)=>[p.id,{front:12+i*2,warehouse:14+i*3}])),tasks:{},achievements:{},events:[],history:[],tick:0});
let s;
try{let raw=JSON.parse(localStorage.getItem(KEY)||'null');if(!raw){const prior=JSON.parse(localStorage.getItem('cuahangtienloi:v99:save1')||'null')||JSON.parse(localStorage.getItem('cuahangtienloi:v96:save1')||'null');if((prior?.version==='99.0'||prior?.version==='96.0')&&prior?.shelves&&prior?.stats)raw={...prior,version:VERSION}}if(raw&&raw.version===VERSION&&raw.stats&&raw.shelves&&items.every(p=>raw.shelves[p.id])){s={...def(),...raw}}else s=def()}catch(e){s=def()}
let activePanel='',saveCounter=0,closedByUser=false,toastTimer=0;
const maxFront=()=>20+s.storeGrade*6;
const isReduced=()=>s.reduceMotion||window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(s))}catch(e){if(!window.__saveWarned){window.__saveWarned=true;toast('⚠️ Bộ nhớ trình duyệt bị hạn chế. Hãy sao lưu qua Cài đặt.')}}};
function beep(happy=true){if(!s.sound)return;try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ctx=window.__chibiAudio||(window.__chibiAudio=new AC());if(ctx.state==='suspended')ctx.resume();const o=ctx.createOscillator(),g=ctx.createGain(),t=ctx.currentTime;o.type='sine';o.frequency.setValueAtTime(happy?660:250,t);o.frequency.exponentialRampToValueAtTime(happy?990:180,t+.09);g.gain.setValueAtTime(.055,t);g.gain.exponentialRampToValueAtTime(.001,t+.14);o.connect(g);g.connect(ctx.destination);o.start(t);o.stop(t+.15)}catch(e){}}
function toast(msg){let el=$('notice');if(!el){el=document.createElement('div');el.id='notice';el.className='sceneToast';$('world').appendChild(el)}el.textContent=msg;el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{el.hidden=true},3000)}
function fxAt(x,y,text){if(isReduced())return;const el=document.createElement('div');el.className='floater';el.textContent=text;el.style.left=x+'%';el.style.top=y+'%';$('fx').appendChild(el);setTimeout(()=>el.remove(),1200)}
function sparkle(x,y,n=3){if(isReduced())return;for(let i=0;i<n;i++){const el=document.createElement('i');el.className='spark';el.style.left=(x+(Math.random()-.5)*5)+'%';el.style.top=(y+(Math.random()-.5)*5)+'%';$('fx').appendChild(el);setTimeout(()=>el.remove(),850)}}
function confetti(){for(let i=0;i<14;i++)setTimeout(()=>sparkle(40+Math.random()*20,40+Math.random()*20,1),i*45)}
function earnXP(amount){s.xp+=amount;const threshold=()=>100+(s.level-1)*90;let leveled=false;while(s.xp>=threshold()){s.xp-=threshold();s.level++;s.gems+=2;s.cash+=55000*s.level;leveled=true}if(leveled){toast('🎉 Lên cấp '+s.level+'! Nhận kim cương và tiền thưởng');confetti();beep()}}
function inStock(){return items.reduce((a,p)=>a+s.shelves[p.id].front,0)}
function inWarehouse(){return items.reduce((a,p)=>a+s.shelves[p.id].warehouse,0)}
function totalCogs(){return s.stats.spent}
function profit(){return s.stats.sales-s.stats.spent-s.stats.wages}
function spawnCustomer(id,found){if(window.Store2D5){window.Store2D5.spawnCustomer(found);return}if(isReduced())return;const el=document.createElement('img');const n=Math.floor(Math.random()*3);el.className='avatar';el.src=window.V100_ASSETS?.['art/customer_'+ 'abc'[n] +'_idle_happy']||`assets/art/customer_${'abc'[n]}_idle_happy.png`;el.alt='';el.style.left='4%';el.style.top='54%';$('npcs').appendChild(el);const dest=found?{x:30+Math.random()*34,y:50+Math.random()*20}:{x:73,y:46};requestAnimationFrame(()=>{el.style.left=dest.x+'%';el.style.top=dest.y+'%'});setTimeout(()=>{el.style.left='22%';el.style.top='84%'},3200);setTimeout(()=>el.remove(),6900)}
function sale(){if(!s.opened)return;const multiplier=s.marketingEnd>s.day?1.4:1;const choices=items.map(p=>({p,weight:p.demand*(s.shelves[p.id].front>0?1:.22)}));const total=choices.reduce((a,b)=>a+b.weight,0);let r=Math.random()*total,selected=choices[0].p;for(const c of choices){r-=c.weight;if(r<=0){selected=c.p;break}}
const shelf=s.shelves[selected.id];s.stats.served++;
if(shelf.front<=0){s.stats.missed++;s.rep=clamp(s.rep-.5,40,100);spawnCustomer(selected.id,false);if(s.stats.missed%4===0)toast('⚠️ Kệ '+selected.name+' đã hết hàng!');return}
const qty=Math.min(shelf.front,Math.random()<.2?2:1);shelf.front-=qty;
const sellPrice=Math.round(selected.price*(s.marketingEnd>s.day?.92:1));const amt=qty*sellPrice;
s.cash+=amt;s.stats.sales+=amt;s.stats.dayRevenue+=amt;s.stats.dayServed++;s.stats.spent+=selected.cost*qty;s.rep=clamp(s.rep+.11,40,100);earnXP(2+s.storeGrade);spawnCustomer(selected.id,true);fxAt(24+Math.random()*10,65,'+'+short(amt));if(s.stats.served%6===0)s.gems++;
}
function nextDay(){s.history.unshift({day:s.day,revenue:s.stats.dayRevenue,served:s.stats.dayServed});s.history=s.history.slice(0,15);if(s.stats.dayRevenue>=220000){s.stats.goodDays++;s.gems+=3}const wages=s.staff*28000+25000+s.storeGrade*5000;s.cash-=wages;s.stats.wages+=wages;s.day++;s.minute=540;s.stats.dayRevenue=0;s.stats.dayServed=0;s.energy=120;s.rep=clamp(s.rep+1,40,100);toast('🌅 Ngày '+s.day+' bắt đầu · Chi phí vận hành '+money(wages));save()}
function tick(){if(document.hidden||!$('welcome').hidden)return;
s.tick++;s.minute+=4;if(s.minute>=1320)nextDay();
if(s.deliveryEnd&&s.tick>=s.deliveryEnd){s.shelves[s.deliveryItem].warehouse+=s.deliveryQty;s.deliveryItem=null;s.deliveryEnd=0;s.deliveryQty=0;toast('📦 Đơn nhập hàng đã về kho!');beep()}
if(s.opened&&s.tick%(s.staff>=4?2:3)===0){sale();if(s.storeGrade>=3&&Math.random()<.4)sale()}
if(s.tick%8===0&&s.energy<120)s.energy=Math.min(120,s.energy+1);
if(s.tick%5===0){save();if(activePanel)renderPanel(activePanel)}renderHUD()}
function renderHUD(){ $('cashLabel').textContent=short(s.cash);$('gemLabel').textContent=s.gems;$('energyLabel').textContent=s.energy+'/120';$('levelLabel').textContent='Cửa hàng trưởng · Lv. '+s.level;const next=100+(s.level-1)*90;$('xpFill').style.width=Math.round(s.xp/next*100)+'%';$('weekday').textContent='Thứ '+(2+(s.day-1)%6)+' · Ngày '+s.day;$('clockLabel').textContent=(s.minute>=1110?'🌙 ':'☀️ ')+String(Math.floor(s.minute/60)).padStart(2,'0')+':'+String(s.minute%60).padStart(2,'0');$('servedLabel').textContent=s.stats.served;$('dayRevenueLabel').textContent=money(s.stats.dayRevenue);$('repLabel').textContent=Math.round(s.rep)+'%';$('signLabel').textContent=s.name+' V100';$('statusLabel').textContent=s.opened?'ĐANG MỞ':'TẠM ĐÓNG';$('openLabel').textContent=s.opened?'Đóng cửa':'Mở cửa';$('openButton').classList.toggle('open',!s.opened);$('openButton').classList.toggle('close',s.opened);$('soundLabel').textContent=s.sound?'Bật':'Tắt';$('world').classList.toggle('night',s.minute>=1110);$('world').classList.toggle('rain',s.day%5===0)}
const panelNames={overview:'🏪 Cửa hàng',staff:'👩‍💼 Nhân viên',orders:'📦 Nhập hàng',stock:'🏠 Kho hàng',products:'🛒 Sản phẩm',reports:'📊 Báo cáo kinh doanh',upgrade:'⬆️ Nâng cấp',decor:'🎨 Trang trí',missions:'📋 Nhiệm vụ',achievements:'🏆 Thành tựu',events:'📅 Sự kiện',settings:'⚙️ Cài đặt',shipping:'🚚 Giao hàng',marketing:'📣 Marketing'};
const button=(act,label,cls='')=>`<button class="action ${cls}" data-cmd="${act}">${label}</button>`;
const heading=(text,detail)=>`<div class="card"><h3>${text}</h3><p class="muted">${detail}</p></div>`;
function rowStock(p,mode){const x=s.shelves[p.id],cap=maxFront();let body=`<div class="card"><div class="row"><img class="itemIcon" src="${imgSrc(p.id)}" alt=""><div style="flex:1"><h3>${p.name}</h3><div class="muted">Kệ: <b>${x.front}/${cap}</b> · Kho: <b>${x.warehouse}</b></div><div class="bar"><i style="width:${Math.min(100,x.front/cap*100)}%"></i></div></div><span style="font-size:12px;color:#146798">${money(p.price)}</span></div><div class="actions">`;
if(mode==='orders')body+=button('buy:'+p.id,`📦 Nhập 12 · ${short(p.cost*12)}`,'secondary');
else body+=button('restock:'+p.id,'🔄 Bổ sung lên kệ','green')+button('buy:'+p.id,'+12 vào kho','secondary');
return body+'</div></div>'}
function renderPanel(name){let html='';switch(name){
case 'overview':html=`<div class="statgrid"><div class="stat"><b>${money(s.cash)}</b><span>Tiền hiện có</span></div><div class="stat"><b>${Math.round(s.rep)}%</b><span>Uy tín</span></div><div class="stat"><b>${inStock()} sản phẩm</b><span>Đang trên kệ</span></div><div class="stat"><b>${s.staff} nhân viên</b><span>Đang làm việc</span></div></div>${heading('🎮 Mục tiêu','Nhập hàng → Bổ sung lên kệ → Mở cửa đón khách → Tăng doanh thu → Nâng cấp cửa hàng.')}<div class="actions">${button('allRestock','🔄 Bổ sung mọi kệ','green')}${button('toggle','🚪 '+(s.opened?'Tạm đóng':'Mở cửa'))}</div><p class="footnote">Đây là phiên bản đồ họa V100 chơi độc lập; bản lưu V95 được giữ nguyên trên trình duyệt.</p>`;break;
case 'products': case 'stock':case 'orders':html=(name==='orders'?heading('📦 Nhập hàng từ nhà cung cấp','Mỗi kiện gồm 12 sản phẩm. Nhập về kho rồi bổ sung lên kệ.'):name==='stock'?heading('🏠 Kiểm soát tồn kho','Hàng tồn kho không tự bày lên kệ; cần bổ sung trước khi bán.'):heading('🛒 Quản lý sản phẩm','Theo dõi tồn trên kệ, tồn kho và giá bán.'))+items.map(p=>rowStock(p,name)).join('')+button('allRestock','🔄 Bổ sung tất cả kệ','green');break;
case 'staff':html=heading('👩‍💼 Đội ngũ cửa hàng','Nhân viên tăng khả năng phục vụ và giữ cửa hàng vận hành.')+`<div class="card"><h3>👥 Nhân sự: ${s.staff} người</h3><p class="muted">Chi phí lương: ${money(s.staff*28000)}/ngày · Tối đa 7 người.</p>${button('hire',`➕ Tuyển người · ${money(250000+s.staff*70000)}`,'green')}</div>`+heading('🌟 Đào tạo','Tuyển và đào tạo thêm nhân viên để tối ưu tốc độ bán hàng ở các cấp cao.');break;
case 'reports':html=`<div class="statgrid">${[['Doanh thu',money(s.stats.sales)],['Giá vốn',money(s.stats.spent)],['Chi phí vận hành',money(s.stats.wages)],['Lợi nhuận dự tính',money(profit())],['Lượt phục vụ',s.stats.served],['Khách bỏ đi',s.stats.missed],['Doanh thu hôm nay',money(s.stats.dayRevenue)],['Tồn kho',inWarehouse()]].map(x=>`<div class="stat"><b>${x[1]}</b><span>${x[0]}</span></div>`).join('')}</div>`+heading('📅 Lịch sử ngày',s.history.length?s.history.map(x=>`Ngày ${x.day}: ${money(x.revenue)} · ${x.served} khách`).join(' · '):'Chưa hoàn tất ngày đầu tiên.');break;
case 'upgrade':{let cost=300000*s.storeGrade;html=heading('🌟 Mở rộng cửa hàng','Mở rộng sức chứa kệ và tăng sức hấp dẫn của cửa hàng.')+`<div class="card"><h3>🏬 Cấp cửa hàng: ${s.storeGrade}</h3><p>Chứa tối đa <b>${maxFront()}</b> sản phẩm mỗi kệ.</p><p class="muted">Mỗi lần nâng cấp tăng sức chứa và tăng tốc độ kiếm XP.</p>${button('upgrade','⬆️ Nâng cấp · '+money(cost),'green')}</div>`;break;}
case 'decor':html=heading('🎨 Thiết kế cửa hàng','Trang trí cải thiện uy tín và tạo cảm giác cửa hàng hiện đại hơn.')+`<div class="card"><h3>✨ Mức trang trí: ${s.decor}</h3><p>Thêm ánh sáng, cây xanh, banner và điểm nhấn màu sắc.</p>${button('decor','🎨 Trang trí · '+money(120000+s.decor*110000),'green')}</div>`;break;
case 'missions':{const tasks=[['stock','Bổ sung hàng lên kệ',inStock()>=110,75000,2],['customers','Phục vụ 20 khách',s.stats.served>=20,120000,3],['sales','Doanh thu đạt 500.000đ',s.stats.sales>=500000,180000,4],['level','Cửa hàng cấp 3',s.storeGrade>=3,350000,8]];html=heading('📋 Nhiệm vụ phát triển','Hoàn thành để nhận tiền và kim cương.')+tasks.map(t=>`<div class="card"><h3>${s.tasks[t[0]]?'✅':t[2]?'🌟':'🔒'} ${t[1]}</h3><div class="muted">Thưởng: ${money(t[3])} +${t[4]} 💎</div><div class="actions">${t[2]&&!s.tasks[t[0]]?button('task:'+t[0],'🎁 Nhận thưởng','green'):''}</div></div>`).join('');break;}
case 'achievements':html=heading('🏆 Thành tựu','Mốc thành tích tích lũy trong quá trình kinh doanh.')+[['🌱 Khởi nghiệp',s.stats.served>=1],['🏬 Cửa hàng phát triển',s.storeGrade>=2],['🛍️ Siêu thị đông khách',s.stats.served>=100],['💰 Nhà kinh doanh',s.stats.sales>=2000000]].map(t=>`<div class="card"><h3>${t[1]?'🏆':'🔒'} ${t[0]}</h3><span class="muted">${t[1]?'Đã đạt':'Đang thực hiện'}</span></div>`).join('');break;
case 'events':html=heading('📅 Sự kiện trong cửa hàng',s.day%5===0?'🌧️ Ngày mưa · Tăng nhu cầu đồ nóng.':'☀️ Ngày kinh doanh · Khách thích mua sắm.')+heading('🎉 Thưởng doanh thu','Nếu ngày có doanh thu từ 220.000đ, bạn được thưởng 3 kim cương khi sang ngày tiếp theo.');break;
case 'shipping':html=heading('🚚 Giao hàng','Hàng nhập được bổ sung ngay vào kho. Chuyển hàng từ kho ra quầy bằng nút Bổ sung.')+button('goto:orders','📦 Đến nhập hàng');break;
case 'marketing':html=heading('📣 Quảng bá và khuyến mãi','Chạy chương trình quảng bá giúp khách đến đông hơn, nhưng giá bán được giảm 8%.')+`<div class="card"><h3>${s.marketingEnd>s.day?'📢 Đang quảng bá':'📦 Không có chiến dịch'}</h3><p class="muted">Còn hiệu lực đến hết ngày ${s.marketingEnd||'—'}.</p>${button('promo','📣 Chạy quảng bá · 180.000đ','green')}</div>`;break;
case 'settings':html=heading('⚙️ Cài đặt iPhone','2.5D Canvas hoạt hình: góc nhìn chéo, không sử dụng WebGL, phù hợp cảm ứng iPhone.')+`<div class="card"><h3>🏷️ Đặt tên cửa hàng</h3><input id="renameInput" style="width:100%;padding:11px;border-radius:10px;border:1px solid #93bad4" maxlength="24" value="${esc(s.name)}">${button('rename','Lưu tên cửa hàng','green')}</div><div class="card"><h3>🖼️ Chất lượng hình ảnh</h3><p class="muted">Chọn chế độ tùy hiệu năng của iPhone. Ưu tiên cân bằng để giữ mượt.</p><div class="actions">${[['eco','Tiết kiệm'],['balanced','Mượt 30 FPS'],['high','HD 45 FPS']].map(q=>button('quality:'+q[0],(s.quality||'balanced')===q[0]?'✓ '+q[1]:q[1],(s.quality||'balanced')===q[0]?'green':'secondary')).join('')}</div></div><div class="card"><h3>📱 Cài đặt lên iPhone</h3><p class="muted">Mở game bằng Safari → Chia sẻ → Thêm vào Màn hình chính. Ở bản đầy đủ, tải game trước khi ngắt mạng để có thể chơi offline.</p></div><div class="card"><h3>🔊 Âm thanh: ${s.sound?'BẬT':'TẮT'}</h3>${button('sound','Chuyển âm thanh','secondary')}</div><div class="card"><h3>🧘 Giảm chuyển động: ${s.reduceMotion?'BẬT':'TẮT'}</h3>${button('reduceMotion','Đổi chế độ','secondary')}</div><div class="card"><h3>💾 Dữ liệu</h3><p class="muted">Tự động lưu tại trình duyệt, sử dụng khóa riêng để không thay dữ liệu V95.</p>${button('export','⬇️ Xuất bản lưu','secondary')}${button('import','⬆️ Nhập bản lưu','secondary')}${button('resetConfirm','🗑️ Bắt đầu lại','warn')}</div><p class="footnote">iPhone: mở bằng Safari → Chia sẻ → Thêm vào Màn hình chính. Để chơi offline cần tải đầy đủ gói từ GitHub Pages và chờ bộ nhớ đệm hoạt động.</p>`;break;
}
$('panelTitle').textContent=panelNames[name]||'Cửa hàng';$('panelBody').innerHTML=html;}
function openPanel(name){activePanel=name;$('panel').classList.add('show');$('backdrop').classList.add('show');renderPanel(name);for(const b of document.querySelectorAll('[data-panel]'))b.classList.toggle('active',b.dataset.panel===name)}
function closePanel(){activePanel='';$('panel').classList.remove('show');$('backdrop').classList.remove('show');document.querySelectorAll('[data-panel]').forEach(b=>b.classList.remove('active'))}
function allRestock(){if(s.energy<1){toast('⚡ Hết năng lượng để bổ sung hàng');return 0}let count=0;for(const p of items){const slot=s.shelves[p.id];const q=Math.min(maxFront()-slot.front,slot.warehouse);if(q>0){slot.front+=q;slot.warehouse-=q;count+=q}}if(count){s.energy=Math.max(0,s.energy-1);toast('✅ Đã bổ sung '+count+' sản phẩm lên kệ');sparkle(65,45,8)}else toast('📦 Kho trống hoặc các kệ đã đầy');return count}
function purchase(id){const p=items.find(x=>x.id===id);if(!p)return;const cost=p.cost*12;if(s.cash<cost){toast('❌ Không đủ tiền nhập hàng');beep(false);return}s.cash-=cost;s.stats.orders++;s.shelves[id].warehouse+=12;toast('📦 Đã nhập 12 '+p.name+' vào kho');beep()}
function action(cmd){if(!cmd)return;const [type,id]=cmd.split(':');if(type==='goto'){openPanel(id);return}if(type==='toggle'){s.opened=!s.opened;toast(s.opened?'🟢 Cửa hàng đã mở đón khách':'🔴 Cửa hàng tạm đóng');beep()}
else if(type==='buy')purchase(id);
else if(type==='restock'){if(s.energy<1){toast('⚡ Hết năng lượng');return}const slot=s.shelves[id],qty=Math.min(maxFront()-slot.front,slot.warehouse);if(qty<1){toast('⚠️ Kho trống hoặc kệ đã đầy');return}slot.front+=qty;slot.warehouse-=qty;s.energy--;toast('🔄 Đã bổ sung '+qty+' sản phẩm');sparkle(66,52,7)}
else if(type==='allRestock')allRestock();
else if(type==='hire'){const cost=250000+s.staff*70000;if(s.staff>=7){toast('👥 Đã đủ 7 nhân viên');return}if(s.cash<cost){toast('❌ Không đủ tiền');return}s.cash-=cost;s.staff++;earnXP(30);toast('🎉 Đã tuyển một nhân viên mới');confetti()}
else if(type==='upgrade'){const cost=300000*s.storeGrade;if(s.cash<cost){toast('❌ Chưa đủ tiền nâng cấp');return}s.cash-=cost;s.storeGrade++;s.rep=clamp(s.rep+2,0,100);earnXP(65);confetti();toast('🏬 Nâng cấp cửa hàng lên cấp '+s.storeGrade)}
else if(type==='decor'){const cost=120000+s.decor*110000;if(s.cash<cost){toast('❌ Chưa đủ tiền trang trí');return}s.cash-=cost;s.decor++;s.rep=clamp(s.rep+5,0,100);sparkle(55,35,14);toast('🎀 Trang trí thành công')}
else if(type==='promo'){if(s.cash<180000){toast('❌ Chưa đủ tiền chạy chiến dịch');return}s.cash-=180000;s.marketingEnd=s.day+2;toast('📣 Đã bật chiến dịch quảng bá trong 2 ngày')}
else if(type==='task'){const tasks={stock:[inStock()>=110,75000,2],customers:[s.stats.served>=20,120000,3],sales:[s.stats.sales>=500000,180000,4],level:[s.storeGrade>=3,350000,8]};const t=tasks[id];if(!t||!t[0]||s.tasks[id])return;s.tasks[id]=true;s.cash+=t[1];s.gems+=t[2];confetti();toast('🎁 Đã nhận thưởng nhiệm vụ!')}
else if(type==='rename'){const v=($('renameInput')?.value||'').trim();if(!v){toast('Vui lòng nhập tên cửa hàng');return}s.name=v.slice(0,24);toast('Đã đổi tên cửa hàng')}
else if(type==='sound'){s.sound=!s.sound;toast(s.sound?'🔊 Đã bật âm thanh':'🔇 Đã tắt âm thanh');beep()}
else if(type==='reduceMotion'){s.reduceMotion=!s.reduceMotion;toast(s.reduceMotion?'🧘 Đã giảm chuyển động':'✨ Đã bật animation')}
else if(type==='quality'){if(['eco','balanced','high'].includes(id)){s.quality=id;toast('🖼️ Đã chọn chất lượng '+id)}}
else if(type==='import'){$('saveImport').click()}
else if(type==='export'){const data=JSON.stringify(s,null,2);const file=new Blob([data],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(file);a.download='Cua_Hang_V100_backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('💾 Đã tạo tệp sao lưu')}
else if(type==='resetConfirm'){if(!window.confirm('Tạo cửa hàng mới? Dữ liệu V100 sẽ bị thay thế, V95 vẫn được giữ nguyên.'))return;s=def();closePanel();toast('Đã tạo cửa hàng mới')}
renderHUD();if(activePanel)renderPanel(activePanel);save()}
document.addEventListener('click',e=>{const panelButton=e.target.closest('[data-panel]');if(panelButton){openPanel(panelButton.dataset.panel);beep();return}const act=e.target.closest('[data-action],[data-cmd]');if(act){action(act.dataset.cmd||act.dataset.action)}});
$('panelClose').addEventListener('click',closePanel);$('backdrop').addEventListener('click',closePanel);document.addEventListener('keydown',e=>{if(e.key==='Escape')closePanel()});$('startGame').addEventListener('click',()=>{$('welcome').hidden=true;toast('🎉 Chào mừng đến với Cửa Hàng Tiện Lợi V100!');beep();save()});
// IMPORTANT: [hidden] must override flex on welcome. This is set via a direct style to support all Safari versions.
$('welcome').hidden=false;
const mo=new MutationObserver(()=>{$('welcome').style.display=$('welcome').hidden?'none':'flex'});mo.observe($('welcome'),{attributes:true,attributeFilter:['hidden']});
$('welcome').style.display='flex';
window.addEventListener('pagehide',save);document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});renderHUD();setInterval(tick,1100);
if('serviceWorker' in navigator&&location.protocol==='https:')window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
// Safe JSON backup import. Backups from V99/V100 are accepted; wrong files do not alter the active game.
const saveImport = document.createElement('input');saveImport.id='saveImport';saveImport.type='file';saveImport.accept='.json,application/json';saveImport.hidden=true;document.body.appendChild(saveImport);
saveImport.addEventListener('change',async()=>{
 const file=saveImport.files?.[0];saveImport.value='';if(!file)return;
 try{
  if(file.size>2000000)throw Error('Tệp vượt giới hạn 2 MB');
  const parsed=JSON.parse(await file.text());
  if(!parsed||!['100.0','99.0'].includes(parsed.version)||!parsed.shelves||!parsed.stats||!items.every(i=>parsed.shelves[i.id]&&Number.isFinite(parsed.shelves[i.id].front)&&Number.isFinite(parsed.shelves[i.id].warehouse)))throw Error('Định dạng bản lưu không phù hợp');
  if(!window.confirm('Nhập bản lưu và thay thế tiến độ V100 trên thiết bị này?'))return;
  s={...def(),...parsed,version:VERSION};save();renderHUD();if(activePanel)renderPanel(activePanel);toast('✅ Đã khôi phục bản lưu');
 }catch(err){toast('⚠️ Không nhập được: '+err.message)}
});
window.ChibiV100={version:VERSION,getState:()=>structuredClone(s),action,openPanel,save,tickForTest:()=>{const was=$('welcome').hidden;$('welcome').hidden=true;tick();$('welcome').hidden=was}};
})();
