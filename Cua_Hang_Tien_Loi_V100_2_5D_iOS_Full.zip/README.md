# Cửa Hàng Tiện Lợi V100 — 2.5D Chibi iOS Edition

**Bản game mô phỏng cửa hàng, dựng bằng Canvas 2D phối cảnh 2.5D**. Có giao diện quản lý và phiên bản trình duyệt độc lập, không yêu cầu WebGL hoặc Unity.

## Chức năng hiện có

- Cửa hàng có quầy thu ngân, tủ lạnh, 6 ngành hàng, cây cảnh, khuyến mãi và kệ phản ánh số lượng hàng còn lại.
- Chibi di chuyển và khách mua hàng tự động; hiệu ứng tiền nổi, ánh sáng, thông báo.
- Nhập hàng, bổ sung kệ, tuyển nhân viên, nâng cấp, trang trí, marketing, doanh thu, nhiệm vụ.
- Camera di chuyển ngang bằng cảm ứng, hỗ trợ iPhone dọc và ngang.
- Ba mức đồ họa: tiết kiệm 24 FPS mục tiêu, cân bằng 30 FPS, HD 45 FPS; FPS thực tế tùy thiết bị.
- Bản lưu riêng V100 và có thể thử khôi phục từ dữ liệu V99/V96 cùng miền; xuất/nhập JSON qua Cài đặt.

## Cách cài bằng một iPhone, 0 đồng

**Đơn giản:** dùng bản HTML độc lập `v100.html` (được cung cấp ngoài tệp ZIP), tải lên thư mục gốc repository `Gane`, đặt nguyên tên `v100.html`.

- Safari → đăng nhập GitHub → mở `https://github.com/tronghoan78787-collab/Gane` → `Add file` → `Upload files` → chọn `v100.html` → `Commit changes`.
- Sau khi GitHub Pages phát hành: mở `https://tronghoan78787-collab.github.io/Gane/v100.html` trong Safari.
- Safari → nút Chia sẻ → **Thêm vào Màn hình chính**. Biểu tượng xuất hiện và có thể mở như một web app.
- **Bản một tệp không có Service Worker offline**. Mở trò chơi qua đường dẫn trực tuyến khi có mạng.

**Bản PWA nhiều tệp có hỗ trợ offline:** tải nguyên nội dung ZIP vào một thư mục riêng `v100_25d/` của repository rồi truy cập `.../Gane/v100_25d/`. Giữ `assets/`, `index.html`, `game.js`, `scene25.js`, `style.css`, `sw.js`, `manifest.webmanifest` đúng tương quan thư mục. Để Service Worker hoàn tất tải cache lần đầu, sau đó mới thử ngắt mạng.

GitHub Pages không tự giải nén ZIP. Đưa mỗi tệp lên dưới đúng đường dẫn.

## Dữ liệu và lưu game

V100 dùng khóa `cuahangtienloi:v100:save1` trong localStorage và không ghi đè dữ liệu V99/V95. Safari có thể xóa dữ liệu lưu do bộ nhớ/chế độ riêng tư; hãy xuất bản lưu JSON tại `Cài đặt → Xuất bản lưu`, và lưu vào ứng dụng Tệp/iCloud Drive.

## Kiểm thử

20/20 bài kiểm thử logic/tích hợp và tính toàn vẹn gói đạt trên Chromium giả lập, bao gồm thao tác giao diện màn hình nhỏ. **Chưa xác nhận Safari trên iPhone thật, FPS thật hoặc mức sử dụng pin**. Cần kiểm tra một lần trên thiết bị thực tế sau khi đăng lên GitHub Pages.

## Bản quyền tài nguyên

Các sprite chibi và hình sản phẩm trong dự án là tài nguyên của bộ game do dự án phát triển, không chứa thư viện bên ngoài. Không dùng tên thương hiệu bên thứ ba nếu phát hành công khai khi chưa có quyền.
